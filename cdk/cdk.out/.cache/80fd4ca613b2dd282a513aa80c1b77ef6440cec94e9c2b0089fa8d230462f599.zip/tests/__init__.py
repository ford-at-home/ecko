"""
Test suite for Echoes API
"""