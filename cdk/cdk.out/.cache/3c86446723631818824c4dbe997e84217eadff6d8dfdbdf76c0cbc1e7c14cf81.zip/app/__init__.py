"""
Echoes Audio Time Machine API

A soulful audio time machine that captures moments as ambient sounds tied to emotion.
"""
__version__ = "1.0.0"
__author__ = "Echoes Team"
__description__ = "Audio time machine API for capturing and recalling emotional moments"